package ph.edu.dlsu.mobdeve.florendo.mapa.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
    }
}